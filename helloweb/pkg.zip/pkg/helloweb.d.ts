/* tslint:disable */
/* eslint-disable */
/**
*/
export function greet(): void;
