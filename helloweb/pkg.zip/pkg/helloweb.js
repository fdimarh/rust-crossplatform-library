import * as wasm from "./helloweb_bg.wasm";
export * from "./helloweb_bg.js";